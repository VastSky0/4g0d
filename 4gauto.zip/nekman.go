echo " Khởi động nekobox sau 4 giây nữa..."
sleep 0.95
echo " Còn 3 giây..."
sleep 0.95
echo " Còn 2 giây..."
sleep 0.95
echo " Còn 1 giây..."
sleep 0.15
clear